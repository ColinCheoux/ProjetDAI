package ajax.bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Classe en charge de la base de données.
 */
public class Bd {

    /*---------*/
 /* Données */
 /*---------*/

 /*----- Connexion -----*/
    private static Connection cx = null;

    /*----- Données de connexion -----*/
    private static final String url = "jdbc:mysql://kolga.ut-capitole.fr:3306/berro";
    private static final String login = "berro";
    private static final String password = "berro";


    /*----------*/
 /* Méthodes */
 /*----------*/
    /**
     * Crée la connexion avec la base de données.
     */
    private static void connexion() throws ClassNotFoundException, SQLException {
        /*----- Chargement du pilote pour la BD -----*/
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            throw new ClassNotFoundException("Pilote pour se connecter à MySql introuvable - " + ex.getMessage());
        }

        /*----- Ouverture de la connexion -----*/
        try {
            Bd.cx = DriverManager.getConnection(url, login, password);
        } catch (SQLException ex) {
            throw new SQLException("Problème de connexion à la base de données - " + ex.getMessage());
        }
    }

    /**
     * Retourne la liste de citations de 'nom_auteur'.
     */
    public static ArrayList<String> lireCitations(String nom_auteur) throws ClassNotFoundException, SQLException {
        /*----- Création de la connexion à la base de données -----*/
        if (Bd.cx == null) {
            Bd.connexion();
        }

        /*----- Espace de requête -----*/
        PreparedStatement st;

        /*----- Requête SQL -----*/
        String sql = "SELECT LibCitation FROM Auteur, Citation WHERE Auteur.IdAuteur=Citation.AutCitation AND Auteur.NomAuteur=?";

        /*----- Ouverture de l'espace de requête -----*/
        try {
            st = Bd.cx.prepareStatement(sql);
        } catch (SQLException ex) {
            throw new SQLException("lireCitations() : Problème d'ouverture de l'espace de requête - " + ex.getMessage());
        }

        /*----- Interrogation de la base -----*/
        ArrayList<String> liste = new ArrayList<>();

        try {
            /*----- Exécution de la requête -----*/
            st.setString(1, nom_auteur);
            ResultSet rs = st.executeQuery();

            /*----- Lecture du contenu du ResultSet -----*/
            while (rs.next()) {
                liste.add(rs.getString(1));
            }
        } catch (SQLException ex) {
            throw new SQLException("lireCitations() : Problème SQL - " + ex.getMessage());
        }

        return liste;
    }

    public static ArrayList<String> lireMots(String mot) throws ClassNotFoundException, SQLException {
        ArrayList<String> liste = new ArrayList<>();
        if (mot != "") {
            /*----- Création de la connexion à la base de données -----*/
            if (Bd.cx == null) {
                Bd.connexion();
            }

            /*----- Espace de requête -----*/
            PreparedStatement st;

            /*----- Requête SQL -----*/
            String sql = "SELECT Texte FROM Mot WHERE lower(Texte) like lower(?)";


            /*----- Ouverture de l'espace de requête -----*/
            try {
                st = Bd.cx.prepareStatement(sql);
            } catch (SQLException ex) {
                throw new SQLException("lireMots() : Problème d'ouverture de l'espace de requête - " + ex.getMessage());
            }

            /*----- Interrogation de la base -----*/
            try {
                /*----- Exécution de la requête -----*/
                st.setString(1, mot + "%");
                ResultSet rs = st.executeQuery();

                /*----- Lecture du contenu du ResultSet -----*/
                while (rs.next()) {
                    liste.add(rs.getString(1));
                }
            } catch (SQLException ex) {
                throw new SQLException("lireMots() : Problème SQL - " + ex.getMessage());
            }
        }
        return liste;
    }

        public static Boolean VerifierMots(String mot) throws ClassNotFoundException, SQLException {
        boolean bool=false;
        if (mot != "") {
            /*----- Création de la connexion à la base de données -----*/
            if (Bd.cx == null) {
                Bd.connexion();
            }

            /*----- Espace de requête -----*/
            PreparedStatement st;

            /*----- Requête SQL -----*/
            String sql = "SELECT Texte FROM Mot WHERE lower(Texte)=lower(?)";


            /*----- Ouverture de l'espace de requête -----*/
            try {
                st = Bd.cx.prepareStatement(sql);
            } catch (SQLException ex) {
                throw new SQLException("lireMots() : Problème d'ouverture de l'espace de requête - " + ex.getMessage());
            }

            /*----- Interrogation de la base -----*/
            try {
                /*----- Exécution de la requête -----*/
                st.setString(1, mot);
                ResultSet rs = st.executeQuery();
                if (!rs.isBeforeFirst() ) {    
                    bool=true; 
                } 
                
            } catch (SQLException ex) {
                throw new SQLException("lireMots() : Problème SQL - " + ex.getMessage());
            }
        }
        return bool;
    }
        
    public static String InsererMot(String mot) throws ClassNotFoundException, SQLException {
        String res = new String();
        res="L'insertion n'a pas pu être effectuée";
        if (!mot.equals(null)) {
            /*----- Création de la connexion à la base de données -----*/
            if (Bd.cx == null) {
                Bd.connexion();
            }

            /*----- Espace de requête -----*/
            PreparedStatement st;

            /*----- Requête SQL -----*/
            String sql = "INSERT INTO Mot VALUES(?)";


            /*----- Ouverture de l'espace de requête -----*/
            try {
                st = Bd.cx.prepareStatement(sql);
            } catch (SQLException ex) {
                throw new SQLException("InsererMots() : Problème d'ouverture de l'espace de requête - " + ex.getMessage());
            }

            /*----- Interrogation de la base -----*/
            try {
                /*----- Exécution de la requête -----*/
                st.setString(1, mot);
                int nb = st.executeUpdate();
                System.out.println(nb);
                res="L'insertion a bien été effectuée";
            } catch (SQLException ex){
                throw new SQLException("InsererMots() : Problème SQL - " + ex.getMessage());
            }
            }
        return res;
    }
    //Testing Method

    public static void main(String[] Args) throws ClassNotFoundException, SQLException {
        Bd unebd = new Bd();
        ArrayList<String> liste = new ArrayList<>();
        try {
            liste = lireMots("a");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Bd.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Bd.class.getName()).log(Level.SEVERE, null, ex);
        }
        String mot=new String();
        mot="Chaos";
        boolean b=unebd.VerifierMots(mot);
        System.out.println(b);
    }
    
} /*----- Fin de la classe Bd -----*/
