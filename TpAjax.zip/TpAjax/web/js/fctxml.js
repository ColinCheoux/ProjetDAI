/**
 * Méthode qui retourne l'objet XMLHttpRequest en fonction du navigateur.
 */
function getXMLHttpRequest()
	{
	var xhr = null;

	// Firefox et bien d'autres.
	if (window.XMLHttpRequest)
		xhr = new XMLHttpRequest();
	else

	// Internet Explorer.
	if (window.ActiveXObject)
		{
		try	{
			xhr = new ActiveXObject("Msxml2.XMLHTTP");
			}
		catch (e)
			{
			xhr = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}

	// XMLHttpRequest non supporté.
	else
		{
		alert("Votre navigateur ne supporte pas l'objet XmlHttpRequest.");
		xhr = false;
		}

	return xhr;
	}


/**
 * Cette méthode "Ajax" affiche le XML.
 *
 * On utilise la propriété 'responseText' de l'objet XMLHttpRequest afin
 * de récupérer sous forme de texte le flux envoyé par le serveur.
 */
function afficheXML ()
	{
	// Objet XMLHttpRequest.
	var xhr = getXMLHttpRequest();

	// On précise ce que l'on va faire quand on aura reçu la réponse du serveur.
	xhr.onreadystatechange = function()
		{
		// Si l'on a tout reçu et que la requête http s'est bien passée.
		if (xhr.readyState === 4 && xhr.status === 200)
			{
			// Elément html que l'on va mettre à jour.
			var elt = document.getElementById("zone");
			elt.innerHTML = xhr.responseText;
			}
		};

	// Requête au serveur avec les paramètres éventuels.
	xhr.open("GET","ServletAuteur",true);
	xhr.send(null);
	}


/**
 * Cette méthode "Ajax" affiche la liste des auteurs.
 *
 * On utilise la propriété 'responseXML' de l'objet XMLHttpRequest afin
 * de récupérer sous forme d'arbre DOM le document XML envoyé par le serveur.
 */
function l_auteurs ()
	{
            // Objet XMLHttpRequest.
            var xhr = getXMLHttpRequest();

            // On précise ce que l'on va faire quand on aura reçu la réponse du serveur.
            xhr.onreadystatechange = function()
                    {
                    // Si l'on a tout reçu et que la requête http s'est bien passée.
                    if (xhr.readyState === 4 && xhr.status === 200)
                            {
                                // liste déroulante que l'on va mettre à jour.
                                var elt = document.getElementById("lnom");
                                elt.innerHTML="<option>--</option>";
                                for(i=0;xhr.responseXML.getElementsByTagName("nom").length;i++){
                                    elt.innerHTML =elt.innerHTML +
                                            "<option value="+
                                            xhr.responseXML.getElementsByTagName("nom")[i].firstChild.nodeValue
                                            +">"+xhr.responseXML.getElementsByTagName("nom")[i].firstChild.nodeValue+
                                            "</option>";
                                }
                            }
                    };

            // Requête au serveur avec les paramètres éventuels.
            xhr.open("GET","ServletAuteur",true);
            xhr.send(null);
	}


/**
 * Cette méthode "Ajax" affiche la liste des citations.
 *
 * On utilise la propriété 'responseXML' de l'objet XMLHttpRequest afin
 * de récupérer sous forme d'arbre DOM le document XML envoyé par le serveur.
 */
function l_citations(selectedObject)
	{
            // Objet XMLHttpRequest.
            var xhr = getXMLHttpRequest();
            // On précise ce que l'on va faire quand on aura reçu la réponse du serveur.
            xhr.onreadystatechange = function()
                    {
                    // Si l'on a tout reçu et que la requête http s'est bien passée.
                    if (xhr.readyState === 4 && xhr.status === 200)
                            {
                                // liste de citations que l'on va mettre à jour.
                                var elt = document.getElementById("lcitations");
                                elt.innerHTML="";
                                for(i=0;xhr.responseXML.getElementsByTagName("citation").length;i++){
                                    elt.innerHTML =elt.innerHTML +
                                            "<p>"+xhr.responseXML.getElementsByTagName("citation")[i].firstChild.nodeValue+
                                            "</p>";
                                }
                            }
                    };

            // Requête au serveur avec les paramètres éventuels.
            xhr.open("GET","ServletCitation?nomauteur="+selectedObject.value+"",true);
            xhr.send(null);
	}


/**
 * Cette méthode "Ajax" simule la zone de recherche 'Google'.
 */
function processKey (selectedObject)
	{
            // Objet XMLHttpRequest.
            var xhr = getXMLHttpRequest();
            
            // On précise ce que l'on va faire quand on aura reçu la réponse du serveur.
            xhr.onreadystatechange = function()
                    {
                    // Si l'on a tout reçu et que la requête http s'est bien passée.
                    if (xhr.readyState === 4 && xhr.status === 200)
                            {
                                // liste de citations que l'on va mettre à jour.
                                var elt = document.getElementById("zoneaff");
                                elt.innerHTML="";
                                for(i=0;xhr.responseXML.getElementsByTagName("mot").length;i++){
                                    elt.innerHTML =elt.innerHTML +
                                            '<p><input type="button" value="'+ xhr.responseXML.getElementsByTagName("mot")[i].firstChild.nodeValue+'" onclick="typevalue(this)" /></p>';
                                }
                            }
                    };
            // Requête au serveur avec les paramètres éventuels.
            xhr.open("GET","ServletGoogle?typedword="+selectedObject.value+"",true);
            xhr.send(null);
	}

function typevalue(selectedObject){
    document.getElementById("saisie").value=selectedObject.value;
    processKey (document.getElementById("saisie"));
}

/**
 * Cette méthode "Ajax" permet de tester les paramètres passés par l'url.
 */
function testEncodeUrl ()
	{
	// Objet XMLHttpRequest.
	var xhr = getXMLHttpRequest();

	// On précise ce que l'on va faire quand on aura reçu la réponse du serveur.
	xhr.onreadystatechange = function()
		{
		// Si l'on a tout reçu et que la requête http s'est bien passée.
		if (xhr.readyState === 4 && xhr.status === 200)
			{
			// Elément html que l'on va mettre à jour.
			document.getElementById("recue").value = xhr.responseXML.getElementsByTagName("msg")[0].firstChild.nodeValue ;
			}
		};

	// Requête au serveur avec les paramètres éventuels.
	var param = "texte=" + encodeURIComponent(document.getElementById("envoie").value);
	var url = "ServletEncode";
	alert(url + "?" + param);

	xhr.open("POST",url,true);
	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	xhr.send(param);
	}

function InsertWord(){
    // Objet XMLHttpRequest.
            var xhr = getXMLHttpRequest();
            var elt = document.getElementById("zonesaisie");
            // On précise ce que l'on va faire quand on aura reçu la réponse du serveur.
            xhr.onreadystatechange = function()
                    {
                    // Si l'on a tout reçu et que la requête http s'est bien passée.
                    if (xhr.readyState === 4 && xhr.status === 200)
                            {
                                // réponse
                                alert(xhr.responseXML.getElementsByTagName("reponse")[0].firstChild.nodeValue);
                            }
                    };

            // Requête au serveur avec les paramètres éventuels.
            xhr.open("GET","ServletInsert?typeword="+elt.value+"",true);
            
            xhr.send(null);
}

function InsertWordGoogle(){
    // Objet XMLHttpRequest.
            var xhr = getXMLHttpRequest();
            var elt = document.getElementById("saisie");
            // On précise ce que l'on va faire quand on aura reçu la réponse du serveur.
            xhr.onreadystatechange = function()
                    {
                    // Si l'on a tout reçu et que la requête http s'est bien passée.
                    if (xhr.readyState === 4 && xhr.status === 200)
                            {
                                // réponse
                                alert(xhr.responseXML.getElementsByTagName("reponse")[0].firstChild.nodeValue);
                            }
                    };

            // Requête au serveur avec les paramètres éventuels.
            xhr.open("GET","ServletInsert?typeword="+elt.value+"",true);
            
            xhr.send(null);
}
